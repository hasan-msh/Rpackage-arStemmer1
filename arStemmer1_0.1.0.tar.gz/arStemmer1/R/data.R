#' @title Data to be used by the package
#' @author Hasan AlShahrani
#' @docType data
#' @format lists Arabic text, prefixes and suffixes
#' @note you need to set the system locale to Arabic to see the data.
#' @export
NULL
