#' Arabic Stemmer
#'
#' Takes in Arabic text, stem it, and save it in the same directory as csv file.
#' @param x file of Arabic text
#' @return the stemmed version of the input file
#' @export
#' @import tokenizers
#'          stringi
arabicStem = function(x){
  library(tokenizers)
  Sys.setlocale("LC_ALL","Arabic")
  x= file.choose()
  x= readLines(x)
  x = tokenize_words(x)
  x= unlist(x)
  library(stringi) # for stri_sub
  ###### replace Teha with Taa Marbutaa#######
  for (i in 1:length(x)){
    x[i] = gsub(teha, "\u0647", x[i])

  }
  ######################################

  for (i in 1:length(x)){
    xx = tokenize_characters(x[i])
    xx = unlist(xx)

    if (x[i]%in% stopWords){
      x[i] = x[i]
    }

    else if ((substr(x[i], 1, 4)%in% pre4)&& length(xx)>=4){
      x[i] = stri_sub(x[i],5)
    }

    else if ((substr(x[i], 1, 3)%in% pre3)&& length(xx)>=4){
      x[i] = stri_sub(x[i],4)
    }
    else if ((substr(x[i], 1, 2)%in% pre2)&& length(xx)>=4){
      x[i] = stri_sub(x[i],3)
    }
    else if ((substr(x[i], 1, 1)%in% pre1)&& length(xx)>=4){
      x[i] = stri_sub(x[i],2)
    }

    else  {
      x[i] = x[i]
    }
  }

  for (i in 1:length(x)){
    xx = tokenize_characters(x[i])
    xx = unlist(xx)
    if (x[i]%in% stopWords){
      x[i] = x[i]
    }
    else if ((stri_sub(x[i], -4, -1)%in% suff4)&& length(xx)>7){
      x[i] = gsub('.{4}$', '', x[i])
    }
    else if ((stri_sub(x[i],-3,-1)%in% suff3)&& length(xx)>6){
      x[i] = gsub('.{3}$', '', x[i])
    }
    else if ((stri_sub(x[i],-2,-1)%in% suff2)&& length(xx)>5){
      x[i] = gsub('.{2}$', '', x[i])
    }
    else if((stri_sub(x[i],-1,-1)%in% suff1)&& length(xx)>4){
      x[i] = gsub('.{1}$', '', x[i])
    }
    else {
      x[i] =  x[i]
    }

  }

  for (i in 1:length(x)){
    xx = tokenize_characters(x[i])
    xx = unlist(xx)

    xx = gsub("\u0623", "\u0627", xx)
    xx = gsub("\u0625", "\u0627", xx)
    xx = gsub("\u0622", "\u0627", xx)
    if (length(xx)>4 && xx[1]=="\u0627" && xx[4]=="\u0627"){
      xx = gsub(xx[1], "", xx)
      xx= paste(xx, collapse = '')
      x[i]=xx
    }
    else {
      x[i] = x[i]
    }
  }

  ################## repeated letters ###########
  for (i in 1:length(x)){
    xx = tokenize_characters(x[i])
    xx = unlist(xx)
    if (length(xx)>3&&xx[1]==xx[2]){
      x[i] = stri_sub(x[i],2)
    }
    else {
      x[i] = x[i]
    }
  }

  ###### remove waaaow from the 4 letters words#######
  for (i in 1:length(x)){
    xx = tokenize_characters(x[i])
    xx = unlist(xx)
    if (length(xx)==4&&xx[3]=="\u0648"){
      x[i] = gsub("\u0648", "", x[i])
    }

  }
  ############ 4 letters, remove the 1st and 4th letters: ex. Tatweer >> tawwara#######
  for (i in 1:length(x)){
    xx = tokenize_characters(x[i])
    xx = unlist(xx)
    if (length(xx)==5&&xx[4]=="\u064A"&& xx[1]=="\u062A"){
      x[i] = gsub("\u064A", "", x[i])
      x[i] = gsub("\u062A", "", x[i])
    }

  }

  ##### remove alif in 2nd positio: Haafiz >> Hafiza####
  for (i in 1:length(x)){
    xx = tokenize_characters(x[i])
    xx = unlist(xx)
    if (length(xx)==4&&xx[2]=="\u0627"){
      x[i] = gsub("\u0627", "", x[i])
    }

  }
  x = as.matrix(x)
  write.csv( x,"stemmedX.csv")

}
